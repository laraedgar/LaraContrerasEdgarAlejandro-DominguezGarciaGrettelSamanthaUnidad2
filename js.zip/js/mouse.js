element.addEventListener('click', function() {
    // Acción a realizar cuando se hace clic
});

element.addEventListener('mouseover', function() {
    // Acción a realizar cuando el mouse entra en el elemento
});

element.addEventListener('mouseout', function() {
    // Acción a realizar cuando el mouse sale del elemento
});

element.addEventListener('mousedown', function() {
    // Acción a realizar cuando se presiona el botón del mouse
});

element.addEventListener('mouseup', function() {
    // Acción a realizar cuando se suelta el botón del mouse
});

element.addEventListener('dblclick', function() {
    // Acción a realizar cuando se hace doble clic
});

